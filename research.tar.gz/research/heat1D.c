/**********************************************************************
 * Anthony Varghese 12.02.2010
 *
 * Parabolic Partial differential equation
 * Heat Equation 1D
 *    - first order in time
 *    - second order in space
 *
 * The heat equation has the form du/dt = D d2u/dx2
 *  - D is the "diffusion coefficient"
 *  - domain: x=0 to x=1
 *  - boundary conditions: du/dx = 0 at x=0, x=1
 *  - initial conditions:  u(x,t=0) = sin(2Pi x);
 * To get the "actual" solution, we can use separation of variables:
 *    We guess that the solution has the form:
 *               u(x,t) = C exp(at) sin(2Pi x)
 *    taking the derivative of this u(x,t) in time:
 *    d u(x,t)/dt = C a exp(at) sin(2Pi x)
 *
 *    taking the 2nd derivative of this in space:
 *    d2 u(x,t)/dx2 = d/dx ( d/dx ( u(x,t) ) )
 *                  = d/dx C exp(at) 2 Pi cos(2Pi x)
 *                  = C exp(at) (-4 Pi^2) sin(2Pi x)
 *    Now, we can use the heat equation:
 *         d u(x,t)/dt = D d2 u/dx2
 *    =>   C a exp(at) sin(2Pi x) = C exp(at) (-4 Pi^2) sin(2Pi x)
 *    => a = -D 4 Pi^2
 * So, for the initial conditions we use, the analytic (or "actual") solution is:
 *   u(x,t) = C exp( -D 4 Pi^2 t) sin( 2 Pi x)
 *
 *
 * The heat equation can be solved numerically using explicit Euler in time and
 * a center-difference finite difference method for the second
 * order spatial derivative:
 *   The space x from 0 to 1 is discretized into N-1 evenly spaced
 *    regions
 *   x0, x1, x2, ... xi-1, xi, xi+1, ... xN-2, xN-1
 *
 *  Use to == t_old
 *      tn == t_new
 *      dt  ==  tn - to
 *      dx  == xi+1 - xi
 *
 * So, we can discretize in time and space to get:
 *
 *   (u(xi,tn) - u(xi,to))/dt = D ( u(xi-1,to) - 2 u(xi,to) + u(xi+1,to))/(dx*dx)
 *
 *   that is, we compute:
 *    u(xi,tn) = u(xi,to) + dt*D( u(xi-1,to) - 2 u(xi,to) + u(xi+1,to))/(dx*dx)
 *
 ********************************************************************************/

# include <stdlib.h>
# include <stdio.h>
# include <math.h>

/*******************************************************************************/
#include <time.h>
#define STRINGSIZE 50
void print_time(char* str) {
  /*
   * Get the current time and
   *  convert it to the "local time"
   */
  time_t current_time = time( NULL );
  const struct tm* time = localtime ( &current_time );

   /********************
    * The tm struct has:
    *   int tm_hour
    *   int tm_min
    *   int tm_sec
    *   and day, month, year, etc.
    *  See the wikipedia article on Time.h
    ***********************************/
  static char time_buffer[STRINGSIZE];
  int len = strftime( time_buffer, STRINGSIZE, "%d %B %I:%M:%S %p", time );
  printf ( "%s: ", str );
  printf ( "%s\n", time_buffer );
}




/*******************************************************************************/
void filewrite( FILE *out, float v[], int length ){
   if ( !out ){
     printf ( "  Warning: invalid file.\n" );
     return;
   }
   if (!v || length <=0 ){
     printf ( "  Warning: no data.\n" );
     return;
   }
   int i=0;
   for ( ; i<length; i++ )
      fprintf ( out, "\t%20.8e", v[i] );
   fprintf ( out, "\n" );
}



/*******************************************************************************/
int main(){
  clock_t start = clock(), diff;
   print_time("Start time");
   /*
    * first open an output file
    */
   const char* filename_time   = "heat1Dtime.out";
   const char* filename_output = "heat1Dcomputed.out";
   const char* filename_actual = "heat1Dactual.out";
   FILE* times  = fopen(filename_time,   "w");
   FILE* output = fopen(filename_output, "w");
   FILE* actual = fopen(filename_actual, "w");
   if (times==0)
     printf("Not able to open %s\n", filename_time );
   if (output==0)
     printf("Not able to open %s\n", filename_output );
   if (actual==0)
     printf("Not able to open %s\n", filename_actual );

   // parameters of the differential equation
   const float D = 5.0E-03;
   // parameters of the actual solution
   const float C = 2.0;
   const float ac = -D * 4 * M_PI * M_PI;

   /*
    * Spatial discretization
    */
   const float x_start = 0.0;
   const float x_end   = 1.0;
   const int x_steps = 5000;
   const float deltax = (x_end - x_start)/(x_steps-1);

   /*
    * Allocate memory for the spatial variables
    */
   const int mem_size = x_steps * sizeof( float );
   float* u_initial = (float*) malloc( mem_size );
   float* u_old     = (float*) malloc( mem_size );
   float* u_new     = (float*) malloc( mem_size );
   float* u_actual  = (float*) malloc( mem_size );

   /*
    * Time discretization
    */
   const float t_start = 0.0; /* initial time value */
   const float t_end   = 5.0;
   const float t_step  = 0.00001;
   const long nsteps   = round((t_end - t_start)/t_step);
   const int print_interval = 10000; // print output every print_interval steps.

   const float coeff = t_step * D /(deltax * deltax);
   printf("Explicit Euler for heat equation: coefficient is: %f\n", coeff);
   if ( coeff >= 0.5 )
    printf ( "  Warning: dt * D / dx2 (%f) is greater than 0.5 ==> results will be inaccurate.\n",
		coeff );
   /*
    *  Set the initial conditions: u_initial
    */
   {
      printf("Number of steps: %d\n", x_steps);
      printf("   delta x:      %f\n", deltax);
      int i=0;
      for (i=0; i<x_steps; i++){
         float angle = 2 * M_PI * i * deltax;
         u_initial[i] = C * sinf( angle );
         // printf( "angle: %f  u: %f\n", angle, u_initial[i]);
         u_old[i] = u_initial[i];
      }
     printf("\n");
   }


   /*
    * Take time steps:
    */
   float time = t_start;
   int i=0;
   for ( ; i<nsteps; i++){
      time += t_step;

      /*
       * Boundary points
       */
      int j=0;     // left boundary point x == 0
      u_new[j] = u_old[j] + coeff * (            -   u_old[j] + u_old[j+1]);
      j=x_steps-1; // right boundary point x == 1
      u_new[j] = u_old[j] + coeff * ( u_old[j-1] -   u_old[j]             );
      /*
       * Non-boundary points
       */
      for (j=1 ; j<x_steps-1; j++)
         u_new[j] = u_old[j] + coeff * ( u_old[j-1] - 2*u_old[j] + u_old[j+1]);

      for (j=0; j<x_steps; j++)
         u_old[j] = u_new[j];

      if ((i%print_interval) == 0){
         fprintf( times, "%f\n", time);
         filewrite (output, u_new, x_steps );
         /*
          * Actual solution
          */
         for( j=0; j<x_steps; j++)
            u_actual[j] = exp( ac * time ) * u_initial[j];
         filewrite (actual, u_actual, x_steps );
      }
   }

   free ( u_actual  );
   free ( u_initial );
   free ( u_old );
   free ( u_new );

   fclose(times);
   fclose(output);
   fclose(actual);
   print_time("End time  ");

   diff = clock() - start;

  int msec = diff * 1000 / CLOCKS_PER_SEC;
  printf("Time taken %d seconds %d milliseconds", msec/1000, msec%1000);
}
